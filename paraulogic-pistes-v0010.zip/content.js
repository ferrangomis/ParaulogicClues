(function () {
  'use strict';

  let sidebar = null;
  let originalData = null; // snapshot of counts before any words are applied

  // ── Data parsing ────────────────────────────────────────────────────────

  function parseTableData() {
    const table = document.getElementById('table_graella');
    if (!table || table.rows.length < 2) return {};

    const headers = Array.from(table.rows[0].cells).map(c => c.textContent.trim());
    const data = {}; // { "d": { 6: 8, 7: 3, ... }, ... }

    for (let r = 1; r < table.rows.length; r++) {
      const row = table.rows[r];
      const letter = row.cells[0]?.textContent.trim();
      if (!letter || letter === 'Σ') continue;
      data[letter] = {};
      for (let c = 1; c < row.cells.length; c++) {
        const len = parseInt(headers[c]);
        if (!isNaN(len)) {
          data[letter][len] = parseInt(row.cells[c].textContent.trim()) || 0;
        }
      }
    }
    return data;
  }

  // Parse "key-count" pairs from a UL element (prefix2, subconjunts, etc.)
  function parsePairs(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return {};
    const data = {};
    const regex = /\b([a-zàáâäçèéêëìíîïòóôöùúûü]+)-(\d+)/g;
    let m;
    while ((m = regex.exec(el.textContent)) !== null) {
      data[m[1]] = parseInt(m[2]);
    }
    return data;
  }

  // Parse "- N de L lletres" lines from tutis / palindroms / quadrats sections
  function parseLengthCounts(elementId) {
    const el = document.getElementById(elementId);
    if (!el) return {};
    const data = {};
    el.querySelectorAll('li').forEach(li => {
      const m = li.textContent.match(/-\s*(\d+)\s+de\s+(\d+)\s+lletres/);
      if (m) data[parseInt(m[2])] = parseInt(m[1]);
    });
    return data;
  }

  // ── Sidebar builders ────────────────────────────────────────────────────

  // Table: clone but annotate each data cell with letter + length data attrs
  function buildTableSection() {
    const source = document.getElementById('table_graella');
    if (!source) return null;

    const table = source.cloneNode(true);
    table.removeAttribute('id');

    if (table.rows.length > 0) {
      const headers = Array.from(table.rows[0].cells).map(c => c.textContent.trim());
      for (let r = 1; r < table.rows.length; r++) {
        const row = table.rows[r];
        const letter = row.cells[0]?.textContent.trim();
        if (!letter || letter === 'Σ') continue;
        for (let c = 1; c < row.cells.length; c++) {
          const len = parseInt(headers[c]);
          if (!isNaN(len)) {
            row.cells[c].dataset.letter = letter;
            row.cells[c].dataset.len = len;
          }
        }
      }
    }
    return table;
  }

  // Pair lists (prefix2, subconjunts): parse and re-render with annotated spans
  // so we can update individual counts later without touching the whole text node.
  function buildPairListSection(elementId) {
    const source = document.getElementById(elementId);
    if (!source) return null;

    const ul = document.createElement('ul');

    const heading = source.querySelector('b.pistes');
    if (heading) ul.appendChild(heading.cloneNode(true));

    const pairs = [];
    const regex = /\b([a-zàáâäçèéêëìíîïòóôöùúûü]+)-(\d+)/g;
    let m;
    while ((m = regex.exec(source.textContent)) !== null) {
      pairs.push({ key: m[1], count: parseInt(m[2]) });
    }

    if (pairs.length > 0) {
      const li = document.createElement('li');
      li.className = 'pairs-container';
      pairs.forEach(({ key, count }) => {
        const span = document.createElement('span');
        span.className = 'pair-item';
        span.dataset.pairKey = key;
        span.dataset.originalCount = count;
        span.innerHTML = `${key}-<span class="pair-count">${count}</span> `;
        li.appendChild(span);
      });
      ul.appendChild(li);
    }

    return ul;
  }

  // Simple sections (prefix3, sufix3, tutis, palindroms, quadrats): just clone
  function buildSimpleSection(elementId) {
    const source = document.getElementById(elementId);
    if (!source) return null;
    const clone = source.cloneNode(true);
    clone.removeAttribute('id');
    return clone;
  }

  // tutis / palindroms / quadrats: rebuild from text rather than cloning,
  // so we don't depend on the source having actual <li> elements.
  function buildLengthCountSection(elementId) {
    const source = document.getElementById(elementId);
    if (!source) return null;

    const ul = document.createElement('ul');

    // Heading: prefer a real <b class="pistes"> if one exists,
    // otherwise extract the text that appears before the first "- N de L lletres" line.
    const existingB = source.querySelector('b.pistes');
    if (existingB) {
      ul.appendChild(existingB.cloneNode(true));
    } else {
      const headingText = source.textContent
        .split(/\s*-\s*\d+\s+de\s+\d+\s+lletres/)[0]
        .trim();
      if (headingText) {
        const b = document.createElement('b');
        b.className = 'pistes';
        b.textContent = headingText;
        ul.appendChild(b);
      }
    }

    // Parse every "- N de L lletres" occurrence from the raw text
    const regex = /-\s*(\d+)\s+de\s+(\d+)\s+lletres/g;
    let m;
    while ((m = regex.exec(source.textContent)) !== null) {
      const count  = parseInt(m[1]);
      const length = parseInt(m[2]);

      const li = document.createElement('li');
      li.dataset.length        = length;
      li.dataset.originalCount = count;
      li.innerHTML = `- <span class="length-count">${count}</span> de ${length} lletres`;
      ul.appendChild(li);
    }

    return ul;
  }

  function buildSidebar() {
    const existing = document.getElementById('pistes-sidebar');
    if (existing) existing.remove();

    sidebar = document.createElement('div');
    sidebar.id = 'pistes-sidebar';

    const title = document.createElement('h2');
    title.className = 'pistes-sidebar-title';
    title.textContent = 'Pistes';
    sidebar.appendChild(title);

    const sections = [
      { id: 'table_graella', build: buildTableSection },
      { id: 'prefix2',       build: () => buildPairListSection('prefix2') },
      { id: 'prefix3',       build: () => buildPairListSection('prefix3') },
      { id: 'sufix3',        build: () => buildPairListSection('sufix3') },
      { id: 'tutis',         build: () => buildLengthCountSection('tutis') },
      { id: 'palindroms',    build: () => buildLengthCountSection('palindroms') },
      { id: 'quadrats',      build: () => buildLengthCountSection('quadrats') },
      { id: 'subconjunts',   build: () => buildPairListSection('subconjunts') },
    ];

    sections.forEach(({ id, build }) => {
      const el = build();
      if (!el) return;
      const wrapper = document.createElement('div');
      wrapper.className = 'pistes-section';
      wrapper.dataset.section = id;
      wrapper.appendChild(el);
      sidebar.appendChild(wrapper);
    });

    sidebar.appendChild(buildAnalysisSection());
    document.body.appendChild(sidebar);
  }

  // ── Word analysis ────────────────────────────────────────────────────────

  // Strip diacritics: àrida → arida, ïlla → illa, etc.
  function normalize(word) {
    return word.normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  function sortedUniqueChars(word) {
    return [...new Set(word.split(''))].sort().join('');
  }

  // Read the available letters from the hex wheel
  function getAvailableChars() {
    const chars = new Set();
    document.querySelectorAll('.hex-link').forEach(link => {
      const ch = link.textContent.trim().toLowerCase();
      if (ch.length === 1) chars.add(ch);
    });
    return chars;
  }

  function isTuti(word) {
    if (!originalData?.availableChars) return false;
    const wordChars = new Set(word.split(''));
    for (const ch of originalData.availableChars) {
      if (!wordChars.has(ch)) return false;
    }
    return true;
  }

  // word is already normalized when these are called
  function isPalindrome(word) {
    return word.length >= 2 && word === [...word].reverse().join('');
  }

  function isSquare(word) {
    if (word.length < 2 || word.length % 2 !== 0) return false;
    const half = word.length / 2;
    return word.slice(0, half) === word.slice(half);
  }

  // Strip any invisible / non-letter characters (zero-width spaces, etc.)
  // Keeps standard Catalan letters and the geminated l (·)
  function cleanWord(w) {
    return w.trim().toLowerCase().replace(/[^\p{L}·]/gu, '');
  }

  function getDiscoveredWords() {
    const el = document.getElementById('discovered-text');
    if (!el) return [];
    return el.textContent
      .split(',')
      .map(w => {
        // "dada o dadà" → only the canonical first form counts
        const mainForm = w.split(' o ')[0];
        return cleanWord(mainForm);
      })
      .filter(w => w.length > 0);
  }

  // Aggregate how many discovered words map to each table cell / prefix / subconjunt
  function computeUsage(words) {
    const tableUsage = {};       // "d:6"   → count
    const prefix2Usage = {};     // "dr"    → count
    const prefix3Usage = {};     // "dru"   → count
    const sufix3Usage = {};      // "ida"   → count
    const subconjuntsUsage = {}; // "adiru" → count
    const tutisUsage = {};       // length  → count
    const palindromsUsage = {};  // length  → count
    const quadratsUsage = {};    // length  → count

    words.forEach(word => {
      const w = normalize(word); // strip accents for all analysis keys
      if (w.length < 2) return;

      const len = w.length;

      const tableKey = `${w[0]}:${len}`;
      tableUsage[tableKey] = (tableUsage[tableKey] || 0) + 1;

      prefix2Usage[w.slice(0, 2)] = (prefix2Usage[w.slice(0, 2)] || 0) + 1;
      prefix3Usage[w.slice(0, 3)] = (prefix3Usage[w.slice(0, 3)] || 0) + 1;
      sufix3Usage[w.slice(-3)]    = (sufix3Usage[w.slice(-3)]    || 0) + 1;

      const chars = sortedUniqueChars(w);
      subconjuntsUsage[chars] = (subconjuntsUsage[chars] || 0) + 1;

      if (isTuti(w))       tutisUsage[len]      = (tutisUsage[len]      || 0) + 1;
      if (isPalindrome(w)) palindromsUsage[len] = (palindromsUsage[len] || 0) + 1;
      if (isSquare(w))     quadratsUsage[len]   = (quadratsUsage[len]   || 0) + 1;
    });

    return {
      tableUsage, prefix2Usage, prefix3Usage, sufix3Usage, subconjuntsUsage,
      tutisUsage, palindromsUsage, quadratsUsage,
    };
  }

  function applyUsage({ tableUsage, prefix2Usage, prefix3Usage, sufix3Usage, subconjuntsUsage, tutisUsage, palindromsUsage, quadratsUsage }) {
    if (!sidebar || !originalData) return;

    // Table cells
    sidebar.querySelectorAll('[data-letter][data-len]').forEach(cell => {
      const letter = cell.dataset.letter;
      const len = parseInt(cell.dataset.len);
      const original = originalData.table[letter]?.[len] ?? 0;
      const used = tableUsage[`${letter}:${len}`] || 0;
      const remaining = original - used;

      if (used > 0) {
        cell.innerHTML = `<span class="updated-count">${remaining}</span>`;
      } else {
        cell.textContent = String(original);
      }
    });

    // Pair sections
    applyUsageToPairs('prefix2', prefix2Usage, originalData.prefix2);
    applyUsageToPairs('prefix3', prefix3Usage, originalData.prefix3);
    applyUsageToPairs('sufix3', sufix3Usage, originalData.sufix3);
    applyUsageToPairs('subconjunts', subconjuntsUsage, originalData.subconjunts);

    // Length-count sections
    applyUsageToLengthSection('tutis',      tutisUsage,      originalData.tutis);
    applyUsageToLengthSection('palindroms', palindromsUsage, originalData.palindroms);
    applyUsageToLengthSection('quadrats',   quadratsUsage,   originalData.quadrats);
  }

  function applyUsageToPairs(sectionId, usageMap, originalCounts) {
    const wrapper = sidebar?.querySelector(`[data-section="${sectionId}"]`);
    if (!wrapper) return;

    wrapper.querySelectorAll('.pair-item').forEach(span => {
      const key = span.dataset.pairKey;
      const original = originalCounts?.[key] ?? parseInt(span.dataset.originalCount) ?? 0;
      const used = usageMap[key] || 0;
      const remaining = original - used;

      const countSpan = span.querySelector('.pair-count');
      if (!countSpan) return;
      countSpan.textContent = remaining;
      countSpan.classList.toggle('updated-count', used > 0);
    });
  }

  function applyUsageToLengthSection(sectionId, usageMap, originalCounts) {
    const wrapper = sidebar?.querySelector(`[data-section="${sectionId}"]`);
    if (!wrapper) return;

    wrapper.querySelectorAll('li[data-length]').forEach(li => {
      const length = parseInt(li.dataset.length);
      const original = originalCounts?.[length] ?? parseInt(li.dataset.originalCount) ?? 0;
      const used = usageMap[length] || 0;
      const remaining = original - used;

      const countSpan = li.querySelector('.length-count');
      if (!countSpan) return;
      countSpan.textContent = remaining;
      countSpan.classList.toggle('updated-count', used > 0);
    });
  }

  // ── Paraules analitzades section ─────────────────────────────────────────

  function buildAnalysisSection() {
    const wrapper = document.createElement('div');
    wrapper.className = 'pistes-section';
    wrapper.dataset.section = 'analisi';

    const ul = document.createElement('ul');

    const heading = document.createElement('b');
    heading.className = 'pistes';
    // "Paraules analitzades" + dynamic count span
    heading.innerHTML = `Paraules analitzades <span class="analisi-count"></span>:`;
    ul.appendChild(heading);

    const list = document.createElement('div');
    list.className = 'analisi-list';
    ul.appendChild(list);

    wrapper.appendChild(ul);
    return wrapper;
  }

  function updateAnalysisSection(words) {
    // Update count in heading
    const countSpan = sidebar?.querySelector('.analisi-count');
    if (countSpan) countSpan.textContent = words.length > 0 ? `(${words.length})` : '';

    const list = sidebar?.querySelector('.analisi-list');
    if (!list) return;
    list.innerHTML = '';

    if (words.length === 0) {
      const empty = document.createElement('span');
      empty.className = 'analisi-empty';
      empty.textContent = '—';
      list.appendChild(empty);
      return;
    }

    words.forEach(word => {
      const w = normalize(word); // use normalized form for all stats
      const len = w.length;
      const p3 = w.slice(0, 3);
      const s3 = w.slice(-3);
      const chars = sortedUniqueChars(w);
      const tuti = isTuti(w);
      const palindrome = isPalindrome(w);
      const square = isSquare(w);

      const row = document.createElement('div');
      row.className = 'analisi-row';

      const wordSpan = document.createElement('span');
      wordSpan.className = 'analisi-word';
      wordSpan.textContent = word;
      row.appendChild(wordSpan);

      const meta = document.createElement('span');
      meta.className = 'analisi-meta';
      meta.textContent = `${len}L · +${p3} · -${s3} · [${chars}]`;
      row.appendChild(meta);

      const badges = document.createElement('span');
      badges.className = 'analisi-badges';
      if (tuti)      badges.innerHTML += '<span class="badge-tuti">★</span>';
      if (palindrome) badges.innerHTML += '<span class="badge-palindrome">↩</span>';
      if (square)    badges.innerHTML += '<span class="badge-square">□</span>';
      if (badges.innerHTML) row.appendChild(badges);

      list.appendChild(row);
    });
  }

  function runAnalysis() {
    if (!sidebar || !originalData) return;
    const words = getDiscoveredWords();
    applyUsage(computeUsage(words));
    updateAnalysisSection(words);
  }

  // ── Watch discovered words for changes ──────────────────────────────────

  function watchDiscoveredWords() {
    function attachObserver() {
      const el = document.getElementById('discovered-text');
      if (!el) return false;
      const observer = new MutationObserver(runAnalysis);
      observer.observe(el, { childList: true, subtree: true, characterData: true });
      return true;
    }

    if (attachObserver()) {
      // Element already present — run analysis immediately to catch pre-loaded words
      runAnalysis();
      return;
    }

    // #discovered-text not in DOM yet — watch body until it appears
    const bodyObserver = new MutationObserver(() => {
      if (attachObserver()) {
        bodyObserver.disconnect();
        runAnalysis();
      }
    });
    bodyObserver.observe(document.body, { childList: true, subtree: true });
  }

  // ── Modal management ─────────────────────────────────────────────────────

  function closePistesModal() {
    const modal = document.getElementById('pistes');
    if (!modal) return;
    const closeLink = modal.querySelector('.close-icon-link');
    if (closeLink) {
      closeLink.click();
    } else {
      modal.classList.remove('active', 'open', 'visible', 'show');
      modal.style.display = 'none';
    }
  }

  function populateAndBuild() {
    const pistesLink = document.getElementById('pistes-link');
    if (!pistesLink) return;

    const table = document.getElementById('table_graella');
    const alreadyPopulated = table && table.rows.length > 1;

    const proceed = () => {
      originalData = {
        table: parseTableData(),
        prefix2: parsePairs('prefix2'),
        prefix3: parsePairs('prefix3'),
        sufix3: parsePairs('sufix3'),
        subconjunts: parsePairs('subconjunts'),
        tutis: parseLengthCounts('tutis'),
        palindroms: parseLengthCounts('palindroms'),
        quadrats: parseLengthCounts('quadrats'),
        availableChars: getAvailableChars(),
      };
      closePistesModal();
      buildSidebar();
      watchDiscoveredWords();
    };

    if (alreadyPopulated) {
      proceed();
    } else {
      pistesLink.click();
      setTimeout(proceed, 300);
    }
  }

  // ── Init ─────────────────────────────────────────────────────────────────

  function init() {
    const checkReady = setInterval(() => {
      if (document.getElementById('pistes-link') && document.getElementById('center-letter')) {
        clearInterval(checkReady);
        populateAndBuild();
      }
    }, 200);
    setTimeout(() => clearInterval(checkReady), 10000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
